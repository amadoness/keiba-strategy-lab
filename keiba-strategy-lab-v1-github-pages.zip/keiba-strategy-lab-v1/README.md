# 競馬戦略研究所 v1.0 / GitHub Pages版

公開済みSites版 v1.0 の機能・UI・架空データを変更せず、HTML / CSS / JavaScript / 年別JSONとしてそのまま出力したものです。AI API・ユーザー登録・ChatGPTへのログインは不要です。

## ファイル

`dist` が配信用ファイル一式です。index.html、style.css、app.js、engine.js、worker.js、data/ をセットで配信してください。HTML単体の直接開きではfetchとWeb Workerが動きません。HTTP/HTTPSで配信して利用します。

`tests` は18件の架空データの手計算との照合、返還、同着、欠損、条件抽出などの計算テストです。Node.jsで `npm test` を実行できます。依存パッケージのインストールは不要です。

`.github/workflows/deploy-pages.yml` は計算・構文検査が成功したときだけ、distをGitHub Pagesへ公開する設定です。mainへの更新で実行します。

## GitHub Pagesで公開

1. GitHubにログインして、Publicリポジトリ `keiba-strategy-lab` を作成します。
2. このフォルダ内のファイルをリポジトリに登録します。フォルダ全体を1段深く入れず、リポジトリ直下に dist / tests / package.json / .github / README.md を配置してください。
3. Settings → Pages → Build and deployment → Source を GitHub Actions にします。
4. Actions → Deploy Keiba Strategy Lab → Run workflow で公開します。
5. ActionsのDeployが成功し、返されたPages URLを確認してから開きます。

GitHubアカウントamadonessで上記リポジトリ名を使った場合、通常の公開先は https://amadoness.github.io/keiba-strategy-lab/ です。このZIP作成時点では、リポジトリ作成・Pages公開はまだ実施していません。URLの稼働は未確認です。

AndroidではChromeなどで公開URLを開きます。インストールは不要です。サイト本体に絶対ルートパスやchatgpt.site固有APIはなく、サブディレクトリでも相対参照で動く構成です。

## 保存データ

保存キーは元版と同じですが、LocalStorageはURLのオリジンごとに独立します。元のchatgpt.siteで保存した戦略は元URLに残り、新しいgithub.ioへ自動転送されません。元URLの設定を見て新URLに再入力・保存してください。今回UIを変えない条件に従い、移行用の追加ボタンは導入していません。

## 検算結果

18Rを各100円、計1,800円購入した場合。

| 戦略 | 的中 | 払戻 | 収支 | 回収率 |
|---|---:|---:|---:|---:|
| 1番人気単勝 | 6R | 1,440円 | -360円 | 80.0% |
| 1番人気複勝 | 9R | 1,170円 | -630円 | 65.0% |
| 2–3番人気ワイド | 12R | 5,730円 | +3,930円 | 318.3% |

実際のJRA成績ではありません。2020〜2025年の架空18レースのみです。計算の13検査とJavaScript構文検査に合格しています。Android実機での表示・保存は未検証です。
