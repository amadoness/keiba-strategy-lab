# V2.1 acceptance audit — 2026-10-04

## Decision

**NOT a completed V2.1 release. Version 2.1.0-preview.2.** Do not promote to 2.1.0 until all requested acceptance gates pass. No ability optimisation performed.

Audited remote main: `64929e9155c260aec51825a6ec6788926995f04f`. Its distributable ZIP Git blob `c7643bb2e2276db6f88f91dc0af33d4da697c3c2` matches the local preview.1 baseline. Changes are limited to input identity validation, tests, version labels and documentation.

## Completed

- Dataset-wide horse_id identity map spans historical races and all upcoming snapshots. Differing exact names, differing supplied birth_year, or female versus male identities reject the entire dataset before indexing or IndexedDB writes. No guessed aliases or automatic repairs. Male/gelding, age, jockey and carried-weight changes are permitted. Optional missing identifiers never erase a known identifier.
- Existing 68 tests retained. Added 7 identity tests and 8 official payout fixture/settlement isolation tests. **83 tests PASS; zero failed/skipped.**
- V1 regression compares 126 settings and full chart values/page HTML/SVG. PASS.
- V1 archive: 12 files identical; V2.0.2 archive: 36 files identical to preserved baseline. No TCG changes.
- Ability, live and engine logic identical after stripping cache-version URL suffixes. Default components 30/20/30/20, prior-run weights 30/25/20/15/10 unchanged.
- Worker data residency, summary projections, 15-row detail pages and strategy storage schema unchanged. Identity-invalid import leaves previous stored data/results available, verified by test.
- Root header/footer/cache-version labels consistently 2.1.0-preview.2. Old /v2.0.2/ and /v1/ left byte-identical.

## Official payout check: limited scope

**One actual race's numerical payout facts; zero full real-schema races imported.** This check only validates the existing settlement path. Injected test selections are synthetic and MUST NOT be described as historical ability ranks or a strategy backtest. Fixture is outside dist, not served as JRA input, and cannot pass validateRealDataset.

- 2024-05-26, Tokyo, Japanese Derby, G1, turf 2400m.
- Source: https://jra.jp/datafile/seiseki/g1/derby/result/derby2024.html
- Access: normal public result page; bounded review/normalisation of horse-number and yen numerical facts only. No article text, images, video, HTML or full result table distributed. No access restrictions bypassed; no recurring scraper included.
- Terms checked: https://jra.jp/use/ (copyright section protects audiovisual/image/article works; this is not a blanket open-data licence). No permission to distribute a complete historical database has been established. These test facts do not imply such permission.
- Source-byte SHA256 retained in tests/fixtures/official/payouts.json. The fixture is explicitly marked notAnImportDataset and notAnAbilityAcceptanceTest.
- Official values per 100 yen: win 5=4660; place 5=700, 15=120, 13=380; wide 5-15=1380, 5-13=8000, 13-15=660; quinella 5-15=6860; exacta 5→15=21490; trio 5-13-15=21250; trifecta 5→15→13=229910.
- Eleven winning combinations × three stakes (100/500/1000 yen) = 33 amount checks. Independently compare stake, payout (official yen100 × stake / 100), profit and ROI with unchanged engine. PASS.
- Example manual 500-yen checks: win payout 23,300 / profit +22,800; quinella payout 34,300 / profit +33,800; trifecta payout 1,149,550 / profit +1,149,050 yen.
- Additional bounded result-page requests returned HTTP 403; acquisition stopped. No fingerprint, proxy, authentication or access-control workaround attempted. No ten-race success claimed.

## Source options investigated

- JRA official public archives provide result/payout facts, but the checked page does not supply all horse IDs, historical pre-off observations or verifiable historical publication timestamps needed for full acceptance. A current retrieval time cannot be backdated into a historical publication timestamp. Name-derived IDs are forbidden. Unknown records are not fabricated.
- JRA-VAN Data Lab: https://developer.jra-van.jp/t/topic/31 documents sample scope/expiry and approved-software distribution requirements. https://developer.jra-van.jp/t/topic/899 describes redistribution constraints. No contract, registration approval or JV-Link installation in this task.
- HRDB-API: https://www.team-nave.com/system/jp/products/kbdbapi/ provides CSV/API JRA-result data from 2000 onwards, at stated 3,300 yen/30 days for personal use. https://www.team-nave.com/system/jp/products/kbdbapi/help_limit.html states one device per licence, up to three queries and 55,555 returned records per query; completeness is not guaranteed. No purchase or contract made. Redistribution rights and availability of historical pre-off timestamps require confirmation before adoption.
- Third-party scraped datasets were not adopted merely because their code repository is public. Source-data rights and actual publication timestamps remain unverified.

## Unmet acceptance gates

| Gate | Status |
| --- | --- |
| At least 10 full real JRA races | 0; pending |
| Race dates/tracks of imported dataset | None |
| Stable horse_id real prior-5-run joins | Pending real dataset; generated tests PASS |
| Ability ranks on at least 10 real races | Pending |
| Future leakage audit on actual 10-race dataset | Pending; generated tests PASS |
| Seven official ticket settlements | One real race, all seven, 33 amount checks PASS; multi-race pending |
| Real reconstructed live entries/cancellation | Pending; generated tests PASS |
| Android real JSON import speed, memory, IDB persistence/reload | Not measured on Android; pending |
| Public completed-version 2.1.0 | Not applied because gates fail |

## Limits

200MB input guard is a file-size guard, not an Android memory guarantee. File text, parsed object, ability index and IndexedDB structured clone may coexist during import. Tens of years of data may exceed mobile memory. Settings-only Worker requests and paged result projections prevent repeated full-dataset/results transfers, but do not eliminate the initial import peak. Native Android IndexedDB quota, reload restoration and responsiveness have not been established by the injected-store unit test. Do not equate desktop/cloud-browser checks to Android hardware tests.

To continue: obtain an authorised dataset containing at least 10 targets plus stable-ID histories, earlier reference clocks, and actual source/publication timestamps; run schema + identity validation, unchanged shared ability evaluation, per-run cutoff audit, independent official payout comparison, and small-data Android native storage/reload testing. Do not infer unknown timestamps, IDs or payouts to pass these gates.
