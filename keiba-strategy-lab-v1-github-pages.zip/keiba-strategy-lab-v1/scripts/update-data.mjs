// Provider-neutral ingestion. Input is normalized JSON, NOT an HTML scraper.
// node scripts/update-data.mjs incoming.json dist/data/v2 [maxNew=500]
import {readFile,writeFile,mkdir,rename,open,unlink} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {validateRace,ticketSizes,orderedTickets} from '../dist/engine.js';
const [input,directory,maxText='500']=process.argv.slice(2);
if(!input||!directory)throw Error('incoming.json とデータディレクトリを指定してください。');
const root=resolve(directory),max=Number(maxText);if(!Number.isSafeInteger(max)||max<1)throw Error('追加件数上限が不正です。');
await mkdir(root,{recursive:true});const lock=join(root,'.update.lock');const handle=await open(lock,'wx');
try{
 const file=join(root,'manifest.json');let previous;
 try{previous=await readFile(file,'utf8');}catch(e){if(e.code!=='ENOENT')throw e;}
 const current=previous?JSON.parse(previous):{schemaVersion:2,files:[],raceCount:0,synthetic:false,upcomingPath:'data/v2/upcoming.json'};
 if(current.schemaVersion!==2)throw Error('スキーマが不正です。');
 const payload=JSON.parse(await readFile(resolve(input),'utf8'));
 if(!payload||!Array.isArray(payload.races)||typeof payload.synthetic!=='boolean'||payload.synthetic!==current.synthetic)throw Error('架空データと本物のデータを混在できません。新規ディレクトリを使用してください。');
 if(payload.races.length>max)throw Error('更新件数が上限を超えました。旧データを維持します。');
 const byId=new Map(),byYear=new Map();
 for(const f of current.files){const name=f.path.split('/').at(-1);if(!/^\d{4}(?:-[\w-]+)?\.json$/.test(name))throw Error('ファイル名が不正です。');const records=JSON.parse(await readFile(join(root,name),'utf8'));for(const r of records){if(byId.has(r.race_id))throw Error('旧データに重複があります。');byId.set(r.race_id,r);}byYear.set(f.year,records);}
 let added=0;const changed=new Set();const seen=new Set();
 for(const r of payload.races){
  validateRace(r);if(seen.has(r.race_id))throw Error('入力に重複race_idがあります。');seen.add(r.race_id);
  if(byId.has(r.race_id)){if(JSON.stringify(byId.get(r.race_id))!==JSON.stringify(r))throw Error('登録済みrace_idの内容変更を検出。明示的なデータ改訂が必要です。');continue;}
  if(r.entries_source!=='pre_off_snapshot'||!Number.isFinite(Date.parse(r.entries_available_at))||Date.parse(r.entries_available_at)>=Date.parse(r.off_at))throw Error('発走前の出走表記録が必要です。');
  if(r.status!=='completed'||!Number.isFinite(Date.parse(r.results_available_at))||Date.parse(r.results_available_at)<=Date.parse(r.off_at)||Date.parse(r.results_available_at)>Date.now())throw Error('公開済みの確定レース結果が必要です。');
  if(r.horses.some(h=>!h.scratched&&(!Number.isSafeInteger(h.time_ms)||h.time_ms<=0||!Number.isSafeInteger(h.margin_ms)||h.margin_ms<0)))throw Error('能力評価の時計・着差が不足しています。');
  for(const [ticket,size] of Object.entries(ticketSizes)){
   const p=r.payouts?.[ticket];if(!p||p.complete!==true||!Array.isArray(p.winners)||!Array.isArray(p.refunds))throw Error(`${r.race_id}: ${ticket}払戻不足`);
   const keys=[...p.winners.map(w=>w.key),...p.refunds];if(new Set(keys).size!==keys.length)throw Error('払戻・返還の重複');
   if(p.winners.some(w=>!Number.isSafeInteger(w.yen100)||w.yen100<10||w.yen100%10))throw Error('払戻金額が不正');
   for(const k of keys){if(typeof k!=='string')throw Error('払戻キーが不正');const ns=k.split('-').map(Number);if(ns.length!==size||new Set(ns).size!==size||ns.join('-')!==k||ns.some(n=>!r.horses.some(h=>h.number===n))||(!orderedTickets.has(ticket)&&ns.some((n,i)=>i&&n<=ns[i-1])))throw Error('払戻組み合わせが不正');}
  }
  const year=+r.date.slice(0,4);if(!byYear.has(year))byYear.set(year,[]);byYear.get(year).push(r);byId.set(r.race_id,r);changed.add(year);added++;
 }
 if(!added){console.log('新しいレースは0件。旧データを維持。');}
 else {
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');await mkdir(join(root,'backups'),{recursive:true});if(previous)await writeFile(join(root,'backups',`manifest-${stamp}.json`),previous,{flag:'wx'});
  const files=current.files.filter(f=>!changed.has(f.year));
  // Versioned shards first; switch manifest atomically last. Failed writes leave old manifest intact.
  for(const year of changed){const name=`${year}-${stamp}.json`;await writeFile(join(root,name),JSON.stringify(byYear.get(year))+'\n',{flag:'wx'});files.push({year,path:`data/v2/${name}`});}
  const next={...current,files:files.sort((a,b)=>a.year-b.year),datasetId:`data-${stamp}`,raceCount:byId.size,updatedAt:new Date().toISOString()};
  const temporary=join(root,'manifest.next.json');await writeFile(temporary,JSON.stringify(next,null,2)+'\n');await rename(temporary,file);console.log(`追加${added}R・合計${byId.size}R。最終更新${next.updatedAt}`);
 }
}finally{await handle.close();await unlink(lock);}
