// Provider-neutral authorized JSON publication; no scraping or acquisition.
import {readFile,writeFile,mkdir,rename,copyFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {validateRealDataset} from '../dist/real-data.js';
const [input,directory='dist/data/real']=process.argv.slice(2);
if(!input)throw Error('入力JSONを指定してください');
const text=await readFile(resolve(input),'utf8'),payload=JSON.parse(text),info=validateRealDataset(payload);
if(payload.provenance.usage!=='public-redistribution-authorized')throw Error('公開する場合は再配布許諾確認後に usage: public-redistribution-authorized を指定してください。個人利用はブラウザ入力を使用してください。');
const root=resolve(directory);await mkdir(root,{recursive:true});const file=join(root,'dataset.json');
try{await copyFile(file,join(root,'dataset.backup-'+Date.now()+'.json'));}catch(e){if(e.code!=='ENOENT')throw e;}
const next=join(root,'dataset.next.json');await writeFile(next,text,{flag:'wx'});await rename(next,file);
console.log(JSON.stringify(info,null,2));
