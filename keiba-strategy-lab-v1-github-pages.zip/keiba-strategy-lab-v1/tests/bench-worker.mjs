// Synthetic stress benchmark: not JRA data or an Android device measurement.
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createRunner} from '../dist/worker.js';
import {backtest,tracks,grades} from '../dist/engine.js';
const source=JSON.parse(readFileSync(new URL('../dist/data/2020.json',import.meta.url)));
const files=Array.from({length:20},(_,i)=>({year:2006+i,path:`data/${2006+i}.json`}));
const data=new Map(files.map(f=>[f.year,Array.from({length:3000},(_,i)=>{
  const r=structuredClone(source[i%3]);r.race_id=`stress-${f.year}-${i}`;
  for(let number=5;number<=18;number++)r.horses.push({...r.horses[0],horse_id:`stress-horse-${number}`,name:`架空追加馬${number}`,number,popularity:number,finish:number});r.runners=18;
  r.date=String(f.year)+r.date.slice(4);r.popularity_at=String(f.year)+r.popularity_at.slice(4);r.off_at=String(f.year)+r.off_at.slice(4);return r;
})]));
let loads=0;const run=createRunner(async url=>{loads++;const y=Number(new URL(url).pathname.match(/(\d{4})\.json$/)[1]);return {ok:true,json:async()=>data.get(y)};},'https://example.test/lab/worker.js');
const cfg={startYear:2006,endYear:2025,minDistance:1000,maxDistance:4000,minRunners:1,maxRunners:18,grades,surfaces:['芝','ダート'],tracks,going:['良','稍重','重','不良'],ticket:'win',rankA:1,rankB:3,stake:100};
await run({type:'init',manifest:{schemaVersion:1,datasetId:'synthetic-stress-60000',files}});
const elapsed=[];
let oldResultBytes,metadataBytes,chartTransferredBytes,maxPageBytes=0;
for(const ticket of ['win','place','wide','win']){
  const config={...cfg,ticket,rankA:ticket==='wide'?2:1};
  const t=performance.now();const r=await run({type:'backtest',config});elapsed.push({ticket,ms:Math.round(performance.now()-t),target:r.target,payout:r.payout});assert.equal(r.target,60000);assert.equal(loads,20);
  const legacy=backtest([...data.values()].flat(),config);
  const {rows,...expected}=legacy,{resultId,chart,...stats}=r;assert.deepEqual(stats,expected);
  let cursor=1;for(const row of rows)if(row.status!=='excluded')assert.equal(chart.balances[cursor++],row.balance);
  assert.equal(cursor,60001);assert.equal('rows' in r,false);assert.equal(chart.titles,null);
  if(oldResultBytes===undefined){
    oldResultBytes=Buffer.byteLength(JSON.stringify({...legacy,rows:[]}))+rows.reduce((n,row)=>n+Buffer.byteLength(JSON.stringify(row)),0)+rows.length-1;
    metadataBytes=Buffer.byteLength(JSON.stringify({...r,chart:{...chart,balances:undefined}}));chartTransferredBytes=chart.balances.byteLength;
  }
  const moved=structuredClone(r,{transfer:[chart.balances.buffer]});assert.equal(chart.balances.byteLength,0);assert.equal(moved.chart.balances.length,60001);
  for(const filter of ['all','hit','loss','excluded']){
    const expectedRows=rows.filter(row=>filter==='all'||row.status===filter);
    for(const page of [1,2,4000]){
      const d=await run({type:'details',resultId,filter,page});assert.equal(d.total,expectedRows.length);assert.ok(d.rows.length<=15);
      assert.deepEqual(d.rows.map(x=>[x.race.date,x.race.name,x.status,x.profit,x.balance]),expectedRows.slice((d.page-1)*15,d.page*15).map(x=>[x.race.date,x.race.name,x.status,x.profit,x.balance]));
      assert.ok(d.rows.every(x=>!('horses' in x.race)&&!('payouts' in x.race)));maxPageBytes=Math.max(maxPageBytes,Buffer.byteLength(JSON.stringify(d)));
    }
  }
}
assert.ok(metadataBytes<20000);assert.equal(chartTransferredBytes,480008);assert.ok(maxPageBytes<20000);
console.log(JSON.stringify({synthetic:true,android:false,races:60000,horsesPerRace:18,years:20,loadsAcrossFourRuns:loads,oldResultBytes,summaryMetadataBytes:metadataBytes,chartTransferredBytes,maxDetailPageBytes:maxPageBytes,chartCopiedBytes:0,elapsed},null,2));
