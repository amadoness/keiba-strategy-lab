// Synthetic stress benchmark: not JRA data or an Android device measurement.
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createRunner} from '../dist/worker.js';
import {tracks,grades} from '../dist/engine.js';
const source=JSON.parse(readFileSync(new URL('../dist/data/2020.json',import.meta.url)));
const files=Array.from({length:20},(_,i)=>({year:2006+i,path:`data/${2006+i}.json`}));
const data=new Map(files.map(f=>[f.year,Array.from({length:3000},(_,i)=>{
  const r=structuredClone(source[i%3]);r.race_id=`stress-${f.year}-${i}`;
  r.date=String(f.year)+r.date.slice(4);r.popularity_at=String(f.year)+r.popularity_at.slice(4);r.off_at=String(f.year)+r.off_at.slice(4);return r;
})]));
let loads=0;const run=createRunner(async url=>{loads++;const y=Number(new URL(url).pathname.match(/(\d{4})\.json$/)[1]);return {ok:true,json:async()=>data.get(y)};},'https://example.test/lab/worker.js');
const cfg={startYear:2006,endYear:2025,minDistance:1000,maxDistance:4000,minRunners:1,maxRunners:18,grades,surfaces:['芝','ダート'],tracks,going:['良','稍重','重','不良'],ticket:'win',rankA:1,rankB:3,stake:100};
await run({type:'init',manifest:{schemaVersion:1,datasetId:'synthetic-stress-60000',files}});
const elapsed=[];
for(const ticket of ['win','place','wide','win']){
  const t=performance.now();const r=await run({type:'backtest',config:{...cfg,ticket,rankA:ticket==='wide'?2:1}});elapsed.push({ticket,ms:Math.round(performance.now()-t),target:r.target,payout:r.payout});assert.equal(r.target,60000);assert.equal(loads,20);
}
console.log(JSON.stringify({synthetic:true,android:false,races:60000,years:20,loadsAcrossFourRuns:loads,configMessageBytes:Buffer.byteLength(JSON.stringify({type:'backtest',config:cfg})),oldRacePayloadBytes:Buffer.byteLength(JSON.stringify([...data.values()].flat())),elapsed},null,2));
