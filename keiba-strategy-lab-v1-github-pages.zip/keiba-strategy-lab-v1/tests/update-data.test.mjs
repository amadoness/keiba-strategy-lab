import test from 'node:test';import assert from 'node:assert/strict';import {mkdtemp,readFile,writeFile,rm,readdir} from 'node:fs/promises';import {tmpdir} from 'node:os';import {join} from 'node:path';import {spawnSync} from 'node:child_process';import {fileURLToPath} from 'node:url';
const script=fileURLToPath(new URL('../scripts/update-data.mjs',import.meta.url)),sample=JSON.parse(await readFile(new URL('../dist/data/v2/2020.json',import.meta.url),'utf8'))[0];
test('週次追加の重複防止・バックアップ・件数異常・欠損・更新失敗時の旧データ保持',async()=>{
 const root=await mkdtemp(join(tmpdir(),'keiba-update-')),directory=join(root,'data'),input=join(root,'input.json');
 const run=()=>spawnSync(process.execPath,[script,input,directory,'2'],{encoding:'utf8'});
 try{
 // Production/synthetic namespaces may not mix.
 await writeFile(input,JSON.stringify({synthetic:true,races:[sample]}));assert.notEqual(run().status,0);
 // New real namespace fixture is labelled false only inside this test, never shipped.
 await writeFile(input,JSON.stringify({synthetic:false,races:[sample]}));assert.equal(run().status,0);
 const initial=await readFile(join(directory,'manifest.json'),'utf8');assert.equal(JSON.parse(initial).raceCount,1);
 assert.equal(run().status,0);assert.equal(await readFile(join(directory,'manifest.json'),'utf8'),initial);
 const second={...structuredClone(sample),race_id:'next'},third={...structuredClone(sample),race_id:'third'};
 await writeFile(input,JSON.stringify({synthetic:false,races:[second]}));assert.equal(run().status,0);assert.equal((await readdir(join(directory,'backups'))).length,1);
 const latest=await readFile(join(directory,'manifest.json'),'utf8');assert.equal(JSON.parse(latest).raceCount,2);
 for(const bad of [[second,{...second,name:'modified'}],[third,third],[third,{...third,race_id:'fourth'},{...third,race_id:'fifth'}],[{...third,payouts:{}}]]){
 await writeFile(input,JSON.stringify({synthetic:false,races:bad}));assert.notEqual(run().status,0);assert.equal(await readFile(join(directory,'manifest.json'),'utf8'),latest);
 }
 }finally{await rm(root,{recursive:true,force:true});}
});
