import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {createRunner} from '../dist/worker.js';
import {backtest,tracks,grades} from '../dist/engine.js';
const manifest=JSON.parse(readFileSync(new URL('../dist/data/manifest.json',import.meta.url)));
const years=new Map(manifest.files.map(f=>[f.year,JSON.parse(readFileSync(new URL('../dist/'+f.path,import.meta.url)))]));
const cfg={startYear:2020,endYear:2025,minDistance:1000,maxDistance:4000,minRunners:1,maxRunners:18,grades,surfaces:['芝','ダート'],tracks,going:['良','稍重','重','不良'],ticket:'win',rankA:1,rankB:3,stake:100};
const request=config=>({type:'backtest',config});
function fixture(){
  const calls=[],fail=new Map();
  const run=createRunner(async url=>{
    const year=Number(new URL(url).pathname.match(/(\d{4})\.json$/)[1]);calls.push(year);
    if(fail.get(year)){fail.set(year,fail.get(year)-1);throw Error('network failure');}
    return {ok:true,json:async()=>structuredClone(years.get(year))};
  },'https://example.test/keiba-strategy-lab/worker.js');
  return {calls,fail,run};
}
const projectRow=r=>({race:Object.fromEntries(['name','date','track','race_number','grade','surface','distance','going','runners'].map(k=>[k,r.race[k]])),status:r.status,reason:r.reason,horses:r.horses.map(h=>Object.fromEntries(['number','name','popularity','odds','finish','jockey'].map(k=>[k,h[k]]))),stake:r.stake,payout:r.payout,refund:r.refund,profit:r.profit,balance:r.balance});
function equalSummary(actual,legacy){
  const {resultId,chart,...stats}=actual,{rows,...expected}=legacy;
  assert.deepEqual(stats,expected);
  assert.equal('rows' in actual,false);
  const purchased=rows.filter(r=>r.status!=='excluded');
  assert.deepEqual([...chart.balances],[0,...purchased.map(r=>r.balance)]);
  assert.equal(chart.firstDate,purchased[0]?.race.date??'');assert.equal(chart.lastDate,purchased.at(-1)?.race.date??'');
  assert.deepEqual(chart.titles,purchased.length<500?purchased.map(r=>({date:r.race.date,name:r.race.name})):null);
}
async function equalPaged(run,actual,legacy){
  equalSummary(actual,legacy);
  for(const filter of ['all','hit','loss','excluded']){
    const expected=legacy.rows.filter(r=>filter==='all'||r.status===filter).map(projectRow);
    const pages=Math.max(1,Math.ceil(expected.length/15)),received=[];
    for(let page=1;page<=pages;page++){
      const part=await run({type:'details',resultId:actual.resultId,filter,page});
      assert.equal(part.rows.length<=15,true);assert.equal(part.page,page);assert.equal(part.pages,pages);assert.equal(part.total,expected.length);received.push(...part.rows);
    }
    assert.deepEqual(received,expected);
  }
}
test('Worker preserves every v1 result and reads each year once across 126 changed configurations',async()=>{
  const {calls,run}=fixture();await run({type:'init',manifest});
  assert.equal(calls.length,0);
  for(const ticket of ['win','place','wide'])for(let startYear=2020;startYear<=2025;startYear++)for(let endYear=startYear;endYear<=2025;endYear++)for(const stake of [100,500]){
    const c={...cfg,ticket,startYear,endYear,stake,rankA:ticket==='wide'?2:1};
    const data=[...years].filter(([y])=>y>=startYear&&y<=endYear).flatMap(([,r])=>r);
    await equalPaged(run,await run(request(c)),backtest(data,c));
  }
  assert.deepEqual(calls,[2020,2021,2022,2023,2024,2025]);
});
test('Narrow initial range loads only requested years; extending loads only uncached years',async()=>{
  const {calls,run}=fixture();await run({type:'init',manifest});
  await run(request({...cfg,startYear:2022,endYear:2023}));assert.deepEqual(calls,[2022,2023]);
  await run(request({...cfg,startYear:2021,endYear:2024}));assert.deepEqual(calls,[2022,2023,2021,2024]);
  await run(request({...cfg,startYear:2022,endYear:2023,grades:['G2']}));assert.equal(calls.length,4);
});
test('Failed year retries without re-reading successful years or returning partial results',async()=>{
  const {calls,fail,run}=fixture();await run({type:'init',manifest});fail.set(2021,1);
  await assert.rejects(run(request(cfg)),/network failure/);
  equalSummary(await run(request(cfg)),backtest([...years.values()].flat(),cfg));
  assert.equal(calls.filter(y=>y===2021).length,2);
  for(const y of [2020,2022,2023,2024,2025])assert.equal(calls.filter(v=>v===y).length,1);
});
test('Identical initialization keeps cache; changed dataset identity clears it',async()=>{
  const {calls,run}=fixture();await run({type:'init',manifest});await run(request(cfg));
  await run({type:'init',manifest:structuredClone(manifest)});await run(request(cfg));assert.equal(calls.length,6);
  await run({type:'init',manifest:{...manifest,datasetId:'new-revision'}});await run(request(cfg));assert.equal(calls.length,12);
});
test('Reject uninitialized, unknown, and invalid config requests before fetching races',async()=>{
  const {calls,run}=fixture();await assert.rejects(run(request(cfg)),/未初期化/);
  await run({type:'init',manifest});await assert.rejects(run({type:'unknown'}));
  await assert.rejects(run(request({...cfg,stake:150})));assert.equal(calls.length,0);
});
test('Malformed data is not cached and can recover on retry',async()=>{
  let attempts=0;const run=createRunner(async()=>({ok:true,json:async()=>++attempts===1?{}:years.get(2020)}));
  await run({type:'init',manifest});const c={...cfg,endYear:2020};await assert.rejects(run(request(c)),/形式/);
  equalSummary(await run(request(c)),backtest(years.get(2020),c));assert.equal(attempts,2);
});
// Exercise the actual app transport, including timeout recovery, without the UI.
function appHarness(){
  const messages=[],instances=[],timers=new Set();
  class Worker {
    constructor(){const f=fixture();this.run=f.run;this.calls=f.calls;instances.push(this);}
    postMessage(data){messages.push(structuredClone(data));this.run(structuredClone(data)).then(result=>{if(!this.terminated)this.onmessage({data:{id:data.id,result:structuredClone(result,result.chart?{transfer:[result.chart.balances.buffer]}:{})}});},e=>{if(!this.terminated)this.onmessage({data:{id:data.id,error:e.message}});});}
    terminate(){this.terminated=true;}
  }
  const source=readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');
  const transport=source.slice(source.indexOf('function workerDiscard('),source.indexOf("$('strategy').onsubmit"));
  const ctx=vm.createContext({Worker,URL,Error,Promise,manifest,setTimeout:fn=>{timers.add(fn);return fn;},clearTimeout:fn=>timers.delete(fn)});
  vm.runInContext('let worker,workerReady,requestId=0;const pendingRequests=new Map();'+transport.replace('import.meta.url',"'https://example.test/keiba-strategy-lab/app.js'")+';this.compute=compute;this.workerRequest=workerRequest;',ctx);
  return {ctx,messages,instances,timers};
}
test('App sends metadata once, then settings only; unchanged engine results',async()=>{
  const {ctx,messages,instances}=appHarness();
  for(const ticket of ['win','place','wide']){
    const c={...cfg,ticket,rankA:ticket==='wide'?2:1};equalSummary(await ctx.compute(c),backtest([...years.values()].flat(),c));
  }
  assert.deepEqual(messages.map(m=>m.type),['init','backtest','backtest','backtest']);
  assert.equal(instances.length,1);assert.equal(instances[0].calls.length,6);
  for(const m of messages){assert.equal('races' in m,false);if(m.type==='backtest')assert.deepEqual(Object.keys(m).sort(),['config','id','type']);}
});
test('App timeout terminates old Worker; next run re-initializes and recalculates correctly',async()=>{
  const {ctx,messages,instances,timers}=appHarness();await ctx.compute(cfg);
  instances[0].postMessage=()=>{};
  const pending=ctx.compute({...cfg,ticket:'place'});const check=assert.rejects(pending,/時間/);await new Promise(resolve=>setImmediate(resolve));
  [...timers][0]();await check;assert.equal(instances[0].terminated,true);
  equalSummary(await ctx.compute(cfg),backtest([...years.values()].flat(),cfg));
  assert.equal(instances.length,2);assert.equal(messages.filter(m=>m.type==='init').length,2);
});

test('Paged results match legacy exclusions, refunds and ties, including global balance',async()=>{
  const data=structuredClone([...years.values()].flat());
  delete data[0].payouts.win;data[1].payouts.win={complete:true,winners:[],refunds:['1']};
  data[2].horses[0].finish=1;data[2].payouts.win.winners=[{key:'1',yen100:150},{key:'2',yen100:230}];
  const run=createRunner(async url=>({ok:true,json:async()=>data.filter(r=>r.date.startsWith(new URL(url).pathname.match(/(\d{4})\.json$/)[1]))}));
  await run({type:'init',manifest});await equalPaged(run,await run(request(cfg)),backtest(data,cfg));
});
test('Invalid pages, filters, stale result IDs and init-reset results are rejected',async()=>{
  const {run}=fixture();await run({type:'init',manifest});const first=await run(request(cfg));
  const base={type:'details',resultId:first.resultId,filter:'all',page:1};
  for(const change of [{page:0},{page:-1},{page:1.2},{page:Infinity},{filter:'refund'},{resultId:0}])await assert.rejects(run({...base,...change}));
  assert.equal((await run({...base,page:999})).page,2);
  await assert.rejects(run(request({...cfg,stake:150})));assert.equal((await run(base)).total,18);
  const next=await run(request({...cfg,ticket:'place'}));await assert.rejects(run(base));assert.notEqual(next.resultId,first.resultId);
  await run({type:'init',manifest:{...manifest,datasetId:'next'}});await assert.rejects(run({...base,resultId:next.resultId}));
});
test('Chart buffer transfers ownership; subsequent paged details remain available',async()=>{
  const {run}=fixture();await run({type:'init',manifest});const s=await run(request(cfg));
  const moved=structuredClone(s,{transfer:[s.chart.balances.buffer]});assert.equal(s.chart.balances.byteLength,0);
  equalSummary(moved,backtest([...years.values()].flat(),cfg));
  await equalPaged(run,moved,backtest([...years.values()].flat(),cfg));
});
test('Transport routes overlapping page requests by ID without replacing pending promises',async()=>{
  const {ctx,instances}=appHarness();const summary=await ctx.compute(cfg);
  const pages=await Promise.all([ctx.workerRequest('details',{resultId:summary.resultId,filter:'all',page:1}),ctx.workerRequest('details',{resultId:summary.resultId,filter:'all',page:2}),ctx.workerRequest('details',{resultId:summary.resultId,filter:'hit',page:1})]);
  assert.deepEqual(pages.map(p=>p.rows.length),[15,3,6]);assert.equal(instances[0].calls.length,6);
});

test('Rendered v1 chart and labels remain byte-for-byte identical',async()=>{
  const oldSource=readFileSync(new URL('./fixtures/v1-app.js',import.meta.url),'utf8');
  const newSource=readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');
  function renderChart(source,result,arg){
    const fields=new Map();const document={getElementById:id=>{if(!fields.has(id))fields.set(id,{});return fields.get(id);}};
    const ctx=vm.createContext({document,Intl,result,arg});
    const begin=source.indexOf('function drawChart('),end=source.indexOf(source.includes('async function renderRaces')?'async function renderRaces':'function renderRaces',begin);
    vm.runInContext(source.split('\n')[1]+'\n'+source.slice(begin,end)+';drawChart(arg);',ctx);
    return Object.fromEntries(fields);
  }
  const {run}=fixture();await run({type:'init',manifest});
  for(const change of [{},{ticket:'place'},{ticket:'wide',rankA:2},{minRunners:10}]){
    const c={...cfg,...change},old=backtest([...years.values()].flat(),c),newResult=await run(request(c));
    assert.deepEqual(renderChart(newSource,newResult,newResult.chart),renderChart(oldSource,old,old.rows));
  }
});

test('Paged detail HTML and pagination match legacy UI for every filter and page',async()=>{
  const oldSource=readFileSync(new URL('./fixtures/v1-details.js',import.meta.url),'utf8');
  const newSource=readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');
  const {run}=fixture();await run({type:'init',manifest});const legacy=backtest([...years.values()].flat(),cfg),summary=await run(request(cfg));
  async function html(source,result,filter,page){
    const fields=new Map([['detailFilter',{value:filter}]]);const document={getElementById:id=>{if(!fields.has(id))fields.set(id,{});return fields.get(id);}};
    const ctx=vm.createContext({document,Intl,result,page,detailVersion:0,statuses:{hit:'的中',loss:'不的中',refund:'返還',excluded:'除外'},workerRequest:(type,payload)=>run({type,...payload})});
    const start=source.indexOf(source.includes('async function renderRaces')?'async function renderRaces':'function renderRaces'),end=source.indexOf("$('detailFilter').onchange",start);
    vm.runInContext(source.split('\n')[1]+'\n'+source.slice(start,end)+';this.draw=renderRaces;',ctx);await ctx.draw();return Object.fromEntries(fields);
  }
  for(const filter of ['all','hit','loss','excluded'])for(const page of [1,2,9])assert.deepEqual(await html(newSource,summary,filter,page),await html(oldSource,legacy,filter,page));
});
test('Late page response never overwrites newer filter selection',async()=>{
  const source=readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');
  const fields=new Map([['detailFilter',{value:'all'}]]),pending=[];
  const document={getElementById:id=>{if(!fields.has(id))fields.set(id,{});return fields.get(id);}};
  const ctx=vm.createContext({document,Intl,result:{resultId:1},page:1,detailVersion:0,statuses:{},workerRequest:(type,payload)=>new Promise(resolve=>pending.push({payload,resolve}))});
  const start=source.indexOf('async function renderRaces'),end=source.indexOf("$('detailFilter').onchange",start);
  vm.runInContext(source.split('\n')[1]+'\n'+source.slice(start,end)+';this.draw=renderRaces;',ctx);
  const first=ctx.draw();fields.get('detailFilter').value='excluded';const second=ctx.draw();
  pending[1].resolve({page:1,pages:1,total:0,rows:[]});await second;assert.equal(fields.get('page').textContent,'1 / 1ページ（0R）');
  pending[0].resolve({page:1,pages:2,total:18,rows:[]});await first;assert.equal(fields.get('page').textContent,'1 / 1ページ（0R）');
});
