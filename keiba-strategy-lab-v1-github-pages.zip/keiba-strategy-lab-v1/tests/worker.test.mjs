import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {createRunner} from '../dist/worker.js';
import {backtest,tracks,grades} from '../dist/engine.js';
const manifest=JSON.parse(readFileSync(new URL('../dist/data/manifest.json',import.meta.url)));
const years=new Map(manifest.files.map(f=>[f.year,JSON.parse(readFileSync(new URL('../dist/'+f.path,import.meta.url)))]));
const cfg={startYear:2020,endYear:2025,minDistance:1000,maxDistance:4000,minRunners:1,maxRunners:18,grades,surfaces:['芝','ダート'],tracks,going:['良','稍重','重','不良'],ticket:'win',rankA:1,rankB:3,stake:100};
const request=config=>({type:'backtest',config});
function fixture(){
  const calls=[],fail=new Map();
  const run=createRunner(async url=>{
    const year=Number(new URL(url).pathname.match(/(\d{4})\.json$/)[1]);calls.push(year);
    if(fail.get(year)){fail.set(year,fail.get(year)-1);throw Error('network failure');}
    return {ok:true,json:async()=>structuredClone(years.get(year))};
  },'https://example.test/keiba-strategy-lab/worker.js');
  return {calls,fail,run};
}
test('Worker preserves every v1 result and reads each year once across 126 changed configurations',async()=>{
  const {calls,run}=fixture();await run({type:'init',manifest});
  assert.equal(calls.length,0);
  for(const ticket of ['win','place','wide'])for(let startYear=2020;startYear<=2025;startYear++)for(let endYear=startYear;endYear<=2025;endYear++)for(const stake of [100,500]){
    const c={...cfg,ticket,startYear,endYear,stake,rankA:ticket==='wide'?2:1};
    const data=[...years].filter(([y])=>y>=startYear&&y<=endYear).flatMap(([,r])=>r);
    assert.deepEqual(await run(request(c)),backtest(data,c));
  }
  assert.deepEqual(calls,[2020,2021,2022,2023,2024,2025]);
});
test('Narrow initial range loads only requested years; extending loads only uncached years',async()=>{
  const {calls,run}=fixture();await run({type:'init',manifest});
  await run(request({...cfg,startYear:2022,endYear:2023}));assert.deepEqual(calls,[2022,2023]);
  await run(request({...cfg,startYear:2021,endYear:2024}));assert.deepEqual(calls,[2022,2023,2021,2024]);
  await run(request({...cfg,startYear:2022,endYear:2023,grades:['G2']}));assert.equal(calls.length,4);
});
test('Failed year retries without re-reading successful years or returning partial results',async()=>{
  const {calls,fail,run}=fixture();await run({type:'init',manifest});fail.set(2021,1);
  await assert.rejects(run(request(cfg)),/network failure/);
  assert.deepEqual(await run(request(cfg)),backtest([...years.values()].flat(),cfg));
  assert.equal(calls.filter(y=>y===2021).length,2);
  for(const y of [2020,2022,2023,2024,2025])assert.equal(calls.filter(v=>v===y).length,1);
});
test('Identical initialization keeps cache; changed dataset identity clears it',async()=>{
  const {calls,run}=fixture();await run({type:'init',manifest});await run(request(cfg));
  await run({type:'init',manifest:structuredClone(manifest)});await run(request(cfg));assert.equal(calls.length,6);
  await run({type:'init',manifest:{...manifest,datasetId:'new-revision'}});await run(request(cfg));assert.equal(calls.length,12);
});
test('Reject uninitialized, unknown, and invalid config requests before fetching races',async()=>{
  const {calls,run}=fixture();await assert.rejects(run(request(cfg)),/未初期化/);
  await run({type:'init',manifest});await assert.rejects(run({type:'unknown'}));
  await assert.rejects(run(request({...cfg,stake:150})));assert.equal(calls.length,0);
});
test('Malformed data is not cached and can recover on retry',async()=>{
  let attempts=0;const run=createRunner(async()=>({ok:true,json:async()=>++attempts===1?{}:years.get(2020)}));
  await run({type:'init',manifest});const c={...cfg,endYear:2020};await assert.rejects(run(request(c)),/形式/);
  assert.deepEqual(await run(request(c)),backtest(years.get(2020),c));assert.equal(attempts,2);
});
// Exercise the actual app transport, including timeout recovery, without the UI.
function appHarness(){
  const messages=[],instances=[],timers=new Set();
  class Worker {
    constructor(){const f=fixture();this.run=f.run;this.calls=f.calls;instances.push(this);}
    postMessage(data){messages.push(structuredClone(data));this.run(structuredClone(data)).then(result=>{if(!this.terminated)this.onmessage({data:{id:data.id,result}});},e=>{if(!this.terminated)this.onmessage({data:{id:data.id,error:e.message}});});}
    terminate(){this.terminated=true;}
  }
  const source=readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');
  const transport=source.slice(source.indexOf('function workerDiscard()'),source.indexOf("$('strategy').onsubmit"));
  const ctx=vm.createContext({Worker,URL,Error,Promise,manifest,setTimeout:fn=>{timers.add(fn);return fn;},clearTimeout:fn=>timers.delete(fn)});
  vm.runInContext('let worker,activeRequest=null,requestId=0;'+transport.replace('import.meta.url',"'https://example.test/keiba-strategy-lab/app.js'")+';this.compute=compute;',ctx);
  return {ctx,messages,instances,timers};
}
test('App sends metadata once, then settings only; unchanged engine results',async()=>{
  const {ctx,messages,instances}=appHarness();
  for(const ticket of ['win','place','wide']){
    const c={...cfg,ticket,rankA:ticket==='wide'?2:1};assert.deepEqual(await ctx.compute(c),backtest([...years.values()].flat(),c));
  }
  assert.deepEqual(messages.map(m=>m.type),['init','backtest','backtest','backtest']);
  assert.equal(instances.length,1);assert.equal(instances[0].calls.length,6);
  for(const m of messages){assert.equal('races' in m,false);if(m.type==='backtest')assert.deepEqual(Object.keys(m).sort(),['config','id','type']);}
});
test('App timeout terminates old Worker; next run re-initializes and recalculates correctly',async()=>{
  const {ctx,messages,instances,timers}=appHarness();await ctx.compute(cfg);
  instances[0].postMessage=()=>{};
  const pending=ctx.compute({...cfg,ticket:'place'});const check=assert.rejects(pending,/時間/);
  [...timers][0]();await check;assert.equal(instances[0].terminated,true);
  assert.deepEqual(await ctx.compute(cfg),backtest([...years.values()].flat(),cfg));
  assert.equal(instances.length,2);assert.equal(messages.filter(m=>m.type==='init').length,2);
});
