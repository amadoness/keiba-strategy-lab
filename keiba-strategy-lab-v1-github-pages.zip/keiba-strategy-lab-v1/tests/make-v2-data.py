# Explicit synthetic fixtures. Never pass these off as real JRA data.
import json, datetime, pathlib
root=pathlib.Path(__file__).resolve().parents[1]/'dist/data/v2'
root.mkdir(exist_ok=True)
names=['アオバスター','ルリノカゼ','コハクランナー','シロガネロード']
rows=[]
for y in range(2018,2026):
 races=[]
 for m in [2,4,6,8,10,12]:
  date=f'{y}-{m:02d}-10';off=date+'T06:00:00Z';i=len(rows)
  finish=[1,2,3,4] if i%3==0 else ([3,1,4,2] if i%3==1 else [2,3,1,4])
  winner_ms=94000+(i%5-2)*100
  hs=[]
  for n in range(1,5):
   margin=(finish[n-1]-1)*(100+n*40)
   hs.append(dict(horse_id=f'v2-fiction-{n}',name=names[n-1],number=n,gate=n,popularity=n,odds=[2.4,4.8,7.6,12][n-1],finish=finish[n-1],margin_ms=margin,time_ms=winner_ms+margin,jockey=f'架空騎手{n}',scratched=False))
  winners=sorted(hs,key=lambda h:h['finish']);a,b,c=[h['number'] for h in winners[:3]]
  key=lambda ns:'-'.join(map(str,sorted(ns)))
  pay={k:dict(complete=True,winners=[],refunds=[]) for k in ['win','place','wide','quinella','exacta','trio','trifecta']}
  pay['win']['winners']=[dict(key=str(a),yen100=240)]
  pay['place']['winners']=[dict(key=str(n),yen100=120+10*j) for j,n in enumerate([a,b])]
  pay['wide']['winners']=[dict(key=key(ns),yen100=360+10*j) for j,ns in enumerate([[a,b],[a,c],[b,c]])]
  for kind,ns,amount in [('quinella',[a,b],480),('exacta',[a,b],960),('trio',[a,b,c],1200),('trifecta',[a,b,c],2400)]:pay[kind]['winners']=[dict(key='-'.join(map(str,ns)) if kind in ['exacta','trifecta'] else key(ns),yen100=amount)]
  race=dict(race_id=f'v2-demo-{y}-{m}',date=date,track='東京',race_number=11,name=f'架空・能力検証 {y}-{m:02d}',grade=['G1','G2','G3'][i%3],surface='芝',distance=1600,going='良',runners=4,status='completed',entries_source='pre_off_snapshot',entries_available_at=date+'T05:00:00Z',off_at=off,results_available_at=date+'T06:15:00Z',popularity_source='pre_off_snapshot',popularity_at=date+'T05:55:00Z',horses=hs,payouts=pay)
  races.append(race);rows.append(race)
 (root/f'{y}.json').write_text(json.dumps(races,ensure_ascii=False,indent=2)+'\n')
up=[]
# A future dated example, not a real scheduled race. All info explicitly synthetic.
for revision,published in enumerate(['2026-10-03T12:00:00+09:00','2026-10-04T09:00:00+09:00']):
 r=dict(race_id='v2-upcoming-demo',name='架空・実戦分析の練習レース',date='2026-10-05',track='東京',race_number=11,grade='G1',surface='芝',distance=1600,going='良',runners=4-revision,status='scheduled',entries_source='pre_off_snapshot',off_at='2026-10-05T15:00:00+09:00',entries_available_at=published,popularity_source='pre_off_snapshot',popularity_at=published,horses=[])
 for n in range(1,5):r['horses'].append(dict(horse_id=f'v2-fiction-{n}',name=names[n-1],number=n,popularity=n,odds=[2.4,4.8,7.6,12][n-1],scratched=revision==1 and n==2,jockey=f'架空騎手{n}'))
 up.append(r)
(root/'upcoming.json').write_text(json.dumps(up,ensure_ascii=False,indent=2)+'\n')
(root/'manifest.json').write_text(json.dumps(dict(schemaVersion=2,datasetId='fiction-v2-48',synthetic=True,raceCount=len(rows),updatedAt='2026-10-03T16:00:00+09:00',upcomingPath='data/v2/upcoming.json',files=[dict(year=y,path=f'data/v2/{y}.json') for y in range(2018,2026)]),ensure_ascii=False,indent=2)+'\n')
