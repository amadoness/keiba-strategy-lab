// 20 years, 60,000 races, 18 runners. Synthetic, development host only.
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createRunner} from '../dist/worker.js';
import {defaultAbility} from '../dist/ability.js';
import {tracks,grades} from '../dist/engine.js';
const files=Array.from({length:20},(_,i)=>({year:2006+i,path:`data/v2/${2006+i}.json`}));
const dataset=new Map();
for(const {year} of files){const races=[];for(let i=0;i<3000;i++){
 const time=new Date(Date.UTC(year,0,1+Math.floor(i/10),1+i%10)),date=time.toISOString().slice(0,10),off=time.toISOString();
 const horses=Array.from({length:18},(_,j)=>{const n=j+1,finish=(j+i)%18+1,margin=(finish-1)*100+n*10;return {horse_id:`h-${i%100}-${n}`,name:`架空馬${i%100}-${n}`,number:n,popularity:n,odds:2+n,finish,margin_ms:finish===1?0:margin,time_ms:94000+(i%5)*100+(finish===1?0:margin),jockey:'架空騎手',scratched:false};});
 const winner=horses.find(h=>h.finish===1).number;
 races.push({race_id:`stress-${year}-${i}`,date,off_at:off,results_available_at:new Date(time.getTime()+1800000).toISOString(),track:'東京',race_number:i%10+1,name:`架空${year}-${i}`,grade:['G1','G2','G3'][i%3],surface:'芝',distance:1600,going:'良',runners:18,status:'completed',entries_source:'pre_off_snapshot',entries_available_at:new Date(time.getTime()-3600000).toISOString(),popularity_source:'pre_off_snapshot',popularity_at:new Date(time.getTime()-60000).toISOString(),horses,payouts:{win:{complete:true,winners:[{key:String(winner),yen100:240}],refunds:[]},place:{complete:true,winners:[{key:String(winner),yen100:120}],refunds:[]}}});
 }dataset.set(year,races);}
let loads=0;const manifest={schemaVersion:2,datasetId:'stress-v2-60000',synthetic:true,raceCount:60000,files,upcomingPath:'data/v2/upcoming.json'};
const run=createRunner(async url=>{loads++;const path=new URL(url).pathname;return {ok:true,json:async()=>path.endsWith('manifest.json')?manifest:path.endsWith('upcoming.json')?[]:dataset.get(+path.match(/(\d{4})\.json$/)[1])};},'https://example.test/worker.js');
await run({type:'init',manifest:{schemaVersion:1,datasetId:'empty-v1',files:[{year:2020,path:'data/2020.json'}]}});
const c={startYear:2006,endYear:2025,minDistance:1000,maxDistance:4000,minRunners:1,maxRunners:18,grades,surfaces:['芝','ダート'],tracks,going:['良','稍重','重','不良'],ticket:'win',rankA:1,rankB:2,rankC:3,stake:100,selection:'ability',ability:defaultAbility(),dataset:'v2-demo'};
const times=[];let original,maximumPageBytes=0,summaryBytes;
for(const change of [{},{},{stake:500},{selection:'popularity'}]){
 const start=performance.now(),r=await run({type:'backtest',config:{...c,...change}});const elapsed=performance.now()-start;
 assert.equal(r.target,60000);assert.equal(loads,22);assert.ok(!('rows' in r));assert.ok(r.purchased>58000);
 const stats={target:r.target,purchased:r.purchased,hits:r.hits,stake:r.stake,payout:r.payout,profit:r.profit,roi:r.roi};
 if(!original)original=stats;else if(!Object.keys(change).length)assert.deepEqual(stats,original);else if(change.stake){assert.equal(r.payout,original.payout*5);assert.equal(r.roi,original.roi);}
 summaryBytes=Buffer.byteLength(JSON.stringify({...r,chart:{...r.chart,balances:undefined}}));assert.ok(summaryBytes<20000);
 for(const filter of ['all','hit','loss','excluded']){const page=await run({type:'details',resultId:r.resultId,filter,page:1});assert.ok(page.rows.length<=15);assert.ok(page.rows.every(row=>!row.race.horses&&!row.race.payouts));maximumPageBytes=Math.max(maximumPageBytes,Buffer.byteLength(JSON.stringify(page)));}
 const bytes=r.chart.balances.byteLength;structuredClone(r,{transfer:[r.chart.balances.buffer]});assert.equal(r.chart.balances.byteLength,0);
 times.push({config:change,elapsedMs:Math.round(elapsed),summaryBytes,chartTransferredBytes:bytes,...stats});
}
assert.ok(maximumPageBytes<30000);
console.log(JSON.stringify({synthetic:true,android:false,races:60000,horsesPerRace:18,years:20,loadsAcrossFourRuns:loads,maximumPageBytes,heapMiB:Math.round(process.memoryUsage().heapUsed/1048576),times},null,2));
