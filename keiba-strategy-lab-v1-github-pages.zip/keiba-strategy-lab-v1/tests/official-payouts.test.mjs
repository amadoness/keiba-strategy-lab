// Settlement-only integration check. Synthetic selection is deliberately injected.
// This is NOT a historical strategy backtest or a full real-schema input fixture.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {backtest,tracks,grades,ticketKey} from '../dist/engine.js';
import {defaultAbility} from '../dist/ability.js';
import {validateRealDataset} from '../dist/real-data.js';
const f=JSON.parse(readFileSync(new URL('./fixtures/official/payouts.json',import.meta.url)));
const cfg={startYear:2024,endYear:2024,minDistance:1000,maxDistance:4000,minRunners:1,maxRunners:18,grades,surfaces:['芝','ダート'],tracks,going:['良'],rankA:1,rankB:2,rankC:3,selection:'ability',ability:defaultAbility(),stake:100};
for(const ticket of ['win','place','wide','quinella','exacta','trio','trifecta'])test('Official Japanese Derby 2024 '+ticket+' payout settles at 100/500/1000 yen',()=>{
 for(const observed of f.races)for(const winner of observed.payouts[ticket])for(const stake of [100,500,1000]){
  const selected=winner.key.split('-').map(Number);
  const r={...observed,race_id:'settlement-test-only',race_number:11,runners:18,status:'completed',going:'良',off_at:'2024-05-26T15:40:00+09:00',entries_source:'pre_off_snapshot',entries_available_at:'2024-05-25T00:00:00+09:00',horses:Array.from({length:18},(_,i)=>({number:i+1,horse_id:'synthetic-'+(i+1),name:'架空選択検算馬'+(i+1)})),payouts:{[ticket]:{complete:true,winners:observed.payouts[ticket].map(w=>({...w,key:ticketKey(ticket,w.key.split('-').map(Number))})),refunds:[]}}};
  // Only exercises unchanged settlement path; NEVER reports these injected ranks as ability results.
  const actual=backtest([r],{...cfg,ticket,stake},{evaluate:()=>selected.map((number,i)=>({number,rank:i+1,score:100-i}))});
  const expected=winner.yen100*stake/100;
  assert.equal(actual.purchased,1);assert.equal(actual.hits,1);assert.equal(actual.stake,stake);assert.equal(actual.payout,expected);assert.equal(actual.profit,expected-stake);assert.equal(actual.roi,expected/stake*100);
 }
});
test('Official payout-only fixture cannot be imported or masquerade as completed real acceptance',()=>{assert.equal(f.notAnImportDataset,true);assert.equal(f.notAnAbilityAcceptanceTest,true);assert.throws(()=>validateRealDataset(f));});
