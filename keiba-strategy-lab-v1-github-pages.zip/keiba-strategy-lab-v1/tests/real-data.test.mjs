// Generated boundary fixtures ONLY. These are not historical JRA observations.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {validateRealDataset,instant} from '../dist/real-data.js';
import {createRunner} from '../dist/worker.js';
import {backtest,tracks,grades} from '../dist/engine.js';
import {defaultAbility,createAbilityIndex} from '../dist/ability.js';
const now=Date.parse('2026-10-04T11:00:00+09:00');
const cfg={startYear:2018,endYear:2025,minDistance:1000,maxDistance:4000,minRunners:1,maxRunners:18,grades,surfaces:['芝','ダート'],tracks,going:['良','稍重','重','不良'],ticket:'win',rankA:1,rankB:2,rankC:3,stake:100,selection:'ability',ability:defaultAbility(),dataset:'jra-real'};
function fixture(){
 const races=Array.from({length:8},(_,i)=>JSON.parse(readFileSync(new URL(`../dist/data/v2/${2018+i}.json`,import.meta.url)))).flat();
 const upcoming=JSON.parse(readFileSync(new URL('../dist/data/v2/upcoming.json',import.meta.url)));
 // All snapshots must be already published for input validation. Move generated dates back.
 for(const r of upcoming){r.date='2026-10-05';r.off_at='2026-10-05T15:00:00+09:00';r.entries_available_at=r.entries_available_at.includes('10-03')?'2026-10-03T12:00:00+09:00':'2026-10-04T09:00:00+09:00';}
 for(const r of [...races,...upcoming]){const active=r.horses.filter(h=>!h.scratched);r.runners=active.length;for(const h of r.horses)if(h.scratched){for(const key of ['popularity','odds','finish','time_ms','margin_ms'])delete h[key];}}
 return {schemaVersion:3,kind:'jra-real',synthetic:false,datasetId:'unit-test-not-jra',provenance:{source:'Generated unit-test input, NOT JRA',usage:'tests only',checkedAt:'2026-10-03T12:00:00+09:00'},races,upcoming};
}
function runner(payload=fixture()){
 let stored=payload,gets=0,puts=0;const calls=[];
 const store={get:async()=>{gets++;return stored;},put:async p=>{puts++;stored=p;},clear:async()=>{stored=null;}};
 const run=createRunner(async url=>{calls.push(url);return {ok:false};},'https://example.test/worker.js',store);
 return {run,calls,store,get gets(){return gets;},get puts(){return puts;}};
}
const manifest=JSON.parse(readFileSync(new URL('../dist/data/manifest.json',import.meta.url)));
test('V2.1 input reads normalized schema, years, provenance and archives final market separately',()=>{
 const p=fixture(),r=p.races[0];delete r.popularity_at;delete r.popularity_source;for(const h of r.horses){h.final_popularity=h.popularity;h.final_odds=h.odds;delete h.popularity;delete h.odds;}
 const info=validateRealDataset(p,now);assert.equal(info.raceCount,48);assert.deepEqual(info.years,[2018,2019,2020,2021,2022,2023,2024,2025]);assert.equal(info.synthetic,false);assert.equal(info.issueCount,1);
 const out=backtest([r],{...cfg,selection:'popularity'});assert.equal(out.purchased,0);assert.equal(out.excluded,1);assert.equal(r.horses[0].final_popularity,1);
});
test('Duplicate race IDs reject entire import',()=>{const p=fixture();p.races.push(p.races[0]);assert.throws(()=>validateRealDataset(p,now),/race_id重複/);});
test('Duplicate horse IDs within race reject; identical lifelong IDs across races accepted',()=>{const p=fixture();assert.doesNotThrow(()=>validateRealDataset(p,now));p.races[0].horses[1].horse_id=p.races[0].horses[0].horse_id;assert.throws(()=>validateRealDataset(p,now),/馬ID/);});
test('Duplicate horse numbers reject',()=>{const p=fixture();p.races[0].horses[1].number=1;assert.throws(()=>validateRealDataset(p,now));});
test('Invalid finish, scratched finish and nonfinished result status reject',()=>{for(const change of [h=>h.finish=0,h=>h.finish=19,h=>h.finish=1.5,h=>h.scratched=true,h=>h.result_status='dnf']){const p=fixture();change(p.races[0].horses[0]);assert.throws(()=>validateRealDataset(p,now));}});
test('Impossible dates, rolled dates, timezone omission and off-date mismatch reject',()=>{for(const date of ['2026-02-30T12:00:00+09:00','2026-10-01T25:00:00+09:00','2026-10-01T12:00:00','2026-10-01T12:60:00Z'])assert.throws(()=>instant(date));const p=fixture();p.races[0].off_at='2017-10-01T15:00:00+09:00';assert.throws(()=>validateRealDataset(p,now),/一致/);});
test('Future or unpublished results reject instead of entering history',()=>{for(const change of [r=>r.results_available_at='2027-01-01T00:00:00Z',r=>r.results_available_at=r.off_at,r=>r.status='scheduled']){const p=fixture();change(p.races[0]);assert.throws(()=>validateRealDataset(p,now));}});
test('Missing payouts stay missing and exclude only affected ticket',()=>{const p=fixture();delete p.races[0].payouts.trio;const info=validateRealDataset(p,now);assert.equal(info.issueCount,1);assert.equal(p.races[0].payouts.trio,undefined);assert.equal(backtest([p.races[0]],{...cfg,selection:'popularity',ticket:'trio'}).excluded,1);assert.equal(backtest([p.races[0]],{...cfg,selection:'popularity',ticket:'win'}).purchased,1);});
test('Duplicate preoff or final popularities reject',()=>{for(const key of ['popularity','final_popularity']){const p=fixture();p.races[0].horses[0][key]=1;p.races[0].horses[1][key]=1;assert.throws(()=>validateRealDataset(p,now),/人気順位/);}});
test('Popularity exact off boundary and after-off observations reject',()=>{for(const offset of [0,1]){const p=fixture(),r=p.races[0];r.popularity_at=new Date(Date.parse(r.off_at)+offset).toISOString();assert.throws(()=>validateRealDataset(p,now),/発走後/);}});
test('Entry count excludes scratched runners; mismatch rejects',()=>{const p=fixture();assert.doesNotThrow(()=>validateRealDataset(p,now));p.races[0].runners++;assert.throws(()=>validateRealDataset(p,now),/馬数/);});
test('Upcoming accepts published snapshots only and refuses results/final odds/payouts',()=>{for(const change of [r=>r.entries_available_at='2027-01-01T00:00:00Z',r=>r.horses[0].finish=1,r=>r.horses[0].final_odds=2,r=>r.payouts={},r=>r.results_available_at='2026-10-05T15:15:00+09:00']){const p=fixture();change(p.upcoming[0]);assert.throws(()=>validateRealDataset(p,now));}});
test('Same-named horses never share histories; target result and after-publication cutoff never enter',()=>{
 const p=fixture();const target=p.races.at(-1);const original=createAbilityIndex(p.races).evaluate(target,cfg.ability);const renamed=structuredClone(p.races);for(const r of renamed)for(const h of r.horses)h.name='同名';
 const rows=createAbilityIndex(renamed).evaluate(renamed.at(-1),cfg.ability);assert.deepEqual(rows.map(h=>[h.horse_id,h.score,h.rank]),original.map(h=>[h.horse_id,h.score,h.rank]));
 const stranger={...target,horses:[{...target.horses[0],horse_id:'no-history',name:'同名'}]};assert.equal(createAbilityIndex(renamed).evaluate(stranger,cfg.ability)[0].score,null);
 const ix=createAbilityIndex(p.races);for(const h of ix.evaluate(target,cfg.ability))for(const past of h.runs)assert.ok(past.date<target.date&&past.race_id!==target.race_id);
});
test('Missing clocks, margins and results publication timestamps are not fabricated',()=>{const p=fixture();delete p.races[0].horses[0].time_ms;delete p.races[0].horses[0].margin_ms;delete p.races[0].results_available_at;const info=validateRealDataset(p,now);assert.equal(info.issueCount,1);assert.equal(p.races[0].results_available_at,undefined);assert.equal(p.races[0].horses[0].margin_ms,undefined);});
test('Demonstration schemas cannot be loaded as real data; missing real never falls back to demo',async()=>{
 for(const patch of [{synthetic:true},{kind:'demo'},{schemaVersion:2},{datasetId:'fiction-v2-48'}])assert.throws(()=>validateRealDataset({...fixture(),...patch},now));
 const x=runner(null);await x.run({type:'init',manifest});await assert.rejects(x.run({type:'backtest',config:cfg}),/未登録/);assert.equal(x.calls.length,1);assert.ok(x.calls[0].endsWith('/data/real/dataset.json'));
});
test('Worker reuses data and index for repeated settings; summaries and pages stay lightweight',async()=>{
 const x=runner();await x.run({type:'init',manifest});const a=await x.run({type:'backtest',config:cfg});const b=await x.run({type:'backtest',config:{...cfg,stake:500}});assert.equal(x.gets,1);assert.equal(x.calls.length,0);assert.equal(b.payout,a.payout*5);assert.equal('rows' in a,false);assert.equal(a.dataInfo.synthetic,false);
 const page=await x.run({type:'details',resultId:b.resultId,filter:'all',page:1});assert.equal(page.rows.length,15);assert.ok(page.rows.every(r=>!r.race.horses&&!r.race.payouts));assert.ok(JSON.stringify(page).length<20000);
});
test('Real input uses same engine results, all 7 tickets and unchanged default formula',async()=>{
 const p=fixture(),x=runner(p);await x.run({type:'init',manifest});const ix=createAbilityIndex(p.races);
 for(const ticket of ['win','place','wide','quinella','exacta','trio','trifecta']){const c={...cfg,ticket};const out=await x.run({type:'backtest',config:c});const expected=backtest(p.races,c,{evaluate:(r,a,t)=>ix.evaluate(r,a,t,false)});for(const k of ['hits','purchased','payout','stake','profit','roi','hitRate','excluded'])assert.equal(out[k],expected[k]);assert.deepEqual([...out.chart.balances],[0,...expected.rows.filter(r=>r.status!=='excluded').map(r=>r.balance)]);}
});
test('File import validates before storage; invalid import and quota failure preserve previous result',async()=>{
 const x=runner();await x.run({type:'init',manifest});const first=await x.run({type:'backtest',config:cfg});const p=fixture();p.races.push(p.races[0]);await assert.rejects(x.run({type:'import-real',file:new Blob([JSON.stringify(p)])}));assert.equal(x.puts,0);assert.ok(await x.run({type:'details',resultId:first.resultId,filter:'all',page:1}));
 x.store.put=async()=>{throw Error('QuotaExceededError');};await assert.rejects(x.run({type:'import-real',file:new Blob([JSON.stringify(fixture())])}),/Quota/);assert.ok(await x.run({type:'details',resultId:first.resultId,filter:'all',page:1}));
});
test('Successful once-only File import persists, invalidates old pages and recovers on new Worker',async()=>{
 const x=runner(null);await x.run({type:'init',manifest});const imported=await x.run({type:'import-real',file:new Blob([JSON.stringify(fixture())])});assert.equal(imported.raceCount,48);assert.equal(x.puts,1);await x.run({type:'backtest',config:cfg});await x.run({type:'backtest',config:cfg});assert.equal(x.puts,1);assert.equal(x.gets,0);
 const fresh=createRunner(async()=>({ok:false}),'https://example.test/worker.js',x.store);await fresh({type:'init',manifest});assert.equal((await fresh({type:'backtest',config:cfg})).payout,(await x.run({type:'backtest',config:cfg})).payout);assert.equal(x.gets,1);
});
test('Published cancellation snapshot automatically recomputes remaining horses; exact off refuses live',async()=>{
 const p=fixture(),x=runner(p);const options={type:'analyze',raceId:p.upcoming[0].race_id,config:cfg};const a=await x.run({...options,asOf:'2026-10-03T18:00:00+09:00'}),b=await x.run({...options,asOf:'2026-10-04T10:00:00+09:00'});assert.equal(a.synthetic,false);assert.equal(a.ranking.find(h=>h.number===2).score===null,false);assert.equal(b.ranking.find(h=>h.number===2).score,null);assert.notEqual(a.candidate.key,b.candidate.key);
 await assert.rejects(x.run({...options,asOf:p.upcoming[0].off_at}));await assert.rejects(x.run({...options,asOf:'2026-10-02T12:00:00+09:00'}));
});
test('Metadata response caps diagnostic details at 15 races and sends no raw records',()=>{const p=fixture();for(const r of p.races)delete r.results_available_at;const info=validateRealDataset(p,now);assert.equal(info.issueCount,48);assert.equal(info.issues.length,15);assert.equal('races' in info,false);assert.equal('horses' in info,false);});
test('Empty complete payout table cannot masquerade as a loss',()=>{const p=fixture();p.races[0].payouts.win={complete:true,winners:[],refunds:[]};assert.throws(()=>validateRealDataset(p,now),/空の払戻表/);});
test('Import rejects missing horse identity and malformed payout keys/amounts',()=>{for(const edit of [r=>r.horses[0].horse_id='',r=>r.payouts.win.winners[0].yen100=241,r=>r.payouts.trio.winners[0].key='3-2-1',r=>r.payouts.win.winners[0].key='19']){const p=fixture();edit(p.races[0]);assert.throws(()=>validateRealDataset(p,now));}});

test('Same horse ID with different names across historical races rejects whole dataset',()=>{
 const p=fixture(),id=p.races[0].horses[0].horse_id;
 const other=p.races.slice(1).flatMap(r=>r.horses).find(h=>h.horse_id===id);assert.ok(other);
 other.name='別馬';assert.throws(()=>validateRealDataset(p,now),/horse_id.*基本識別情報.*全体/);
});
test('Historical and upcoming horse identities must agree',()=>{
 const p=fixture(),h=p.upcoming[0].horses[0];const past=p.races.flatMap(r=>r.horses).find(x=>x.horse_id===h.horse_id);assert.ok(past);
 h.name=past.name+'別馬';assert.throws(()=>validateRealDataset(p,now),/基本識別情報/);
});
test('Different names across upcoming snapshots reject even without historical races',()=>{
 const p=fixture();p.races=[];const a=p.upcoming[0],b=structuredClone(a);b.entries_available_at='2026-10-04T08:00:00+09:00';b.horses[0].name='別馬';p.upcoming=[a,b];assert.throws(()=>validateRealDataset(p,now),/基本識別情報/);
});
test('Supplied conflicting birth years or female versus male identities reject',()=>{
 for(const field of ['birth_year','sex']){const p=fixture(),h=p.races[0].horses[0],other=p.races.slice(1).flatMap(r=>r.horses).find(x=>x.horse_id===h.horse_id);h[field]=field==='sex'?'牝':2015;other[field]=field==='sex'?'牡':2016;assert.throws(()=>validateRealDataset(p,now),/基本識別情報/);}
});
test('Normal ageing, gelding, jockey and weight changes preserve identity',()=>{
 const p=fixture(),id=p.races[0].horses[0].horse_id;let i=0;
 for(const r of [...p.races,...p.upcoming])for(const h of r.horses)if(h.horse_id===id){h.birth_year=2015;h.age=3+i%8;h.sex=i++?'せん':'牡';h.jockey='騎手'+i;h.weight=54+i%5;}
 assert.doesNotThrow(()=>validateRealDataset(p,now));
});
test('Missing optional identity fields do not hide later conflicting known values',()=>{
 const p=fixture(),id=p.races[0].horses[0].horse_id,hs=p.races.flatMap(r=>r.horses).filter(h=>h.horse_id===id);assert.ok(hs.length>=3);
 for(const h of hs)delete h.birth_year;hs[1].birth_year=2015;hs[2].birth_year=2016;assert.throws(()=>validateRealDataset(p,now),/基本識別情報/);
});
test('Identity-conflicting File never saves or replaces prior Worker results',async()=>{
 const x=runner();await x.run({type:'init',manifest});const first=await x.run({type:'backtest',config:cfg});
 const p=fixture(),id=p.races[0].horses[0].horse_id;p.races.slice(1).flatMap(r=>r.horses).find(h=>h.horse_id===id).name='別馬';
 await assert.rejects(x.run({type:'import-real',file:new Blob([JSON.stringify(p)])}),/基本識別情報/);assert.equal(x.puts,0);
 assert.ok(await x.run({type:'details',resultId:first.resultId,filter:'all',page:1}));assert.equal((await x.run({type:'backtest',config:cfg})).payout,first.payout);
});
