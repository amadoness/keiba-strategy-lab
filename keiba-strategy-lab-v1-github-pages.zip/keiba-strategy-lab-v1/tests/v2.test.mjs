import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createAbilityIndex,defaultAbility,validateAbility,DEFAULT_COMPONENTS,DEFAULT_RUNS} from '../dist/ability.js';
import {backtest,tracks,grades,ticketKey} from '../dist/engine.js';
import {analyzeRace} from '../dist/live.js';
import {createRunner} from '../dist/worker.js';
const cfg={startYear:2018,endYear:2025,minDistance:1000,maxDistance:4000,minRunners:1,maxRunners:18,grades,surfaces:['芝','ダート'],tracks,going:['良','稍重','重','不良'],ticket:'win',rankA:1,rankB:2,rankC:3,stake:100,selection:'ability',ability:defaultAbility(),dataset:'v2-demo'};
const read=f=>JSON.parse(readFileSync(new URL('../dist/'+f,import.meta.url)));
const races=Array.from({length:8},(_,i)=>read(`data/v2/${2018+i}.json`)).flat(),upcoming=read('data/v2/upcoming.json');
function race(id,date,hs,extra={}){return {race_id:id,date,entries_source:'pre_off_snapshot',entries_available_at:date+'T05:00:00Z',off_at:date+'T06:00:00Z',results_available_at:date+'T06:15:00Z',track:'東京',race_number:11,name:id,grade:'G1',surface:'芝',distance:1600,going:'良',runners:3,status:'completed',popularity_source:'pre_off_snapshot',popularity_at:date+'T05:55:00Z',horses:hs,payouts:{win:{complete:true,winners:[{key:'1',yen100:240}],refunds:[]}},...extra};}
const horse=(id,n=1,extra={})=>({horse_id:id,name:id,number:n,popularity:n,odds:2,finish:1,time_ms:90000,margin_ms:0,...extra});
const seed=race('seed','2019-01-01',[horse('seed')]);
const past=race('past','2020-01-01',[horse('a',1,{finish:2,time_ms:91000,margin_ms:500}),horse('winner',2)]);
const target=race('target','2020-02-01',[horse('a'),horse('new',2)]);
test('能力手計算：格100×30%＋着順50×20%＋着差90×30%＋時計40×20%=75',()=>{
 const row=createAbilityIndex([seed,past]).evaluate(target,defaultAbility())[0];assert.equal(row.score,75);assert.deepEqual(row.components,[100,50,90,40]);assert.equal(row.runs[0].weight,100);assert.equal(row.runs[0].reference.time_ms,90000);assert.equal(row.rank,1);
});
test('4項目の重み変更、過去走重み変更、3走の30/25/20再配分を手計算',()=>{
 const history=[seed,...['2020-01-01','2020-01-10','2020-01-20'].map((date,i)=>race('p'+i,date,[horse('a')],{grade:['G1','G2','G3'][i]}))];
 const a={components:[100,0,0,0],runs:[30,25,20,15,10]};const index=createAbilityIndex(history),r=index.evaluate(target,a)[0];
 assert.equal(r.score,80*30/75+90*25/75+100*20/75);r.runs.forEach((x,i)=>assert.ok(Math.abs(x.weight-[40,100/3,80/3][i])<1e-12));
 assert.equal(index.evaluate(target,{components:[0,100,0,0],runs:[100,0,0,0,0]})[0].score,100);
 assert.notEqual(index.evaluate(target,{...a,runs:[100,0,0,0,0]})[0].score,r.score);
});
test('再現性・入力順変更・市場人気とオッズを変更しても能力点不変',()=>{
 const a=createAbilityIndex(races).evaluate(upcoming[0],cfg.ability,upcoming[0].entries_available_at);
 const edited=structuredClone(races).reverse();for(const r of edited)for(const h of r.horses){h.popularity=18;h.odds=999;}
 assert.deepEqual(createAbilityIndex(edited).evaluate(upcoming[0],cfg.ability,upcoming[0].entries_available_at),a);
});
test('新馬・不足する基準時計・時計・着差・公開日時は推測しない',()=>{
 assert.equal(createAbilityIndex([]).evaluate(target,cfg.ability)[0].score,null);
 assert.equal(createAbilityIndex([past]).evaluate(target,cfg.ability).find(h=>h.number===1).score,null);
 for(const change of [p=>delete p.results_available_at,p=>delete p.horses[0].time_ms,p=>delete p.horses[0].margin_ms,p=>p.results_available_at='2020-03-01T00:00:00Z']){const p=structuredClone(past);change(p);assert.equal(createAbilityIndex([seed,p]).evaluate(target,cfg.ability).find(h=>h.number===1).score,null);}
 // Zero-weight data are not required.
 assert.equal(createAbilityIndex([past]).evaluate(target,{components:[100,0,0,0],runs:[30,25,20,15,10]})[0].score,100);
});
test('基準時計は同場・コース・距離・馬場のみに限定、対象当日・将来・未公開を使わない',()=>{
 const expected=createAbilityIndex([seed,past]).evaluate(target,cfg.ability)[0];
 const future=race('future','2021-01-01',[horse('a',1,{time_ms:1000})]);
 const sameDay=race('same-day',target.date,[horse('a',1,{time_ms:1000})]);
 const late=race('late','2019-12-01',[horse('a',1,{time_ms:1000})],{results_available_at:'2020-03-01T00:00:00Z'});
 const wrong=Object.entries({track:'中山',surface:'ダート',distance:1800,going:'重'}).map(([k,v],i)=>race('wrong'+i,'2019-12-15',[horse('x',1,{time_ms:1000})],{[k]:v}));
 assert.deepEqual(createAbilityIndex([seed,past,future,sameDay,late,...wrong]).evaluate(target,cfg.ability)[0],expected);
});
test('各過去走の基準に、その過去走以降の結果を入れない',()=>{
 const changed=race('later-baseline','2020-01-15',[horse('other',1,{time_ms:1000})]);
 assert.equal(createAbilityIndex([seed,past,changed]).evaluate(target,cfg.ability)[0].score,75);
});
test('公開順が走行日順と異なる履歴も、直近5走はレース日順',()=>{
 const many=Array.from({length:10},(_,i)=>race('h'+i,`2020-01-${String(i+1).padStart(2,'0')}`,[horse('a')]));many[0].results_available_at='2020-01-25T00:00:00Z';
 const row=createAbilityIndex([seed,...many]).evaluate(target,cfg.ability)[0];assert.deepEqual(row.runs.map(x=>x.race_id),['h9','h8','h7','h6','h5']);
});
test('完全同点は1,1,3位。丸めた表示の同点では順位を混ぜない',()=>{
 const p=race('p','2020-01-01',[horse('a'),horse('b',2),horse('c',3,{finish:3})]);const t=race('t','2020-02-01',[horse('a'),horse('b',2),horse('c',3)]);const ix=createAbilityIndex([seed,p]);
 const ranking=ix.evaluate(t,cfg.ability);assert.deepEqual(ranking.map(h=>h.rank),[1,1,3]);
 assert.equal(backtest([t],cfg,{evaluate:ix.evaluate}).excluded,1);
});
test('7券種・順序あり／なしの購入・払戻を独立した固定額で検算',()=>{
 const r=races[0];for(const [ticket,payout] of [['win',240],['place',120],['wide',360],['quinella',480],['exacta',960],['trio',1200],['trifecta',2400]]){
 const c={...cfg,selection:'popularity',ticket};const result=backtest([r],c);assert.equal(result.hits,1);assert.equal(result.stake,100);assert.equal(result.payout,payout);assert.equal(result.profit,payout-100);assert.equal(result.roi,payout);
 const reverse={...c,rankA:2,rankB:1};if(['quinella','wide','trio'].includes(ticket))assert.equal(backtest([r],reverse).payout,payout);if(['exacta','trifecta'].includes(ticket))assert.equal(backtest([r],reverse).payout,0);
 }
 assert.equal(ticketKey('trio',[3,1,2]),'1-2-3');assert.equal(ticketKey('trifecta',[3,1,2]),'3-1-2');
});
test('追加券種も欠損・不正・返還・同着の実払戻を処理、外れを着順から捏造しない',()=>{
 for(const ticket of ['quinella','exacta','trio','trifecta']){const r=structuredClone(races[0]),c={...cfg,selection:'popularity',ticket};delete r.payouts[ticket];assert.equal(backtest([r],c).excluded,1);
 r.payouts[ticket]={complete:true,winners:[],refunds:[ticketKey(ticket,[1,2,3].slice(0,['trio','trifecta'].includes(ticket)?3:2))]};assert.equal(backtest([r],c).refund,100);
 r.payouts[ticket].refunds=[];assert.equal(backtest([r],c).payout,0);
 r.payouts[ticket].winners=[{key:'1-1',yen100:200}];assert.equal(backtest([r],c).excluded,1);
 }
});
test('実戦とバックテストで同じ評価関数・順位・候補を使用',()=>{
 const ix=createAbilityIndex(races),entry={...upcoming[0],date:'2025-12-10',entries_available_at:'2025-12-09T12:00:00+09:00',off_at:'2025-12-10T15:00:00+09:00',status:'scheduled'};
 const c={...cfg,rankA:1,ability:{components:[100,0,0,0],runs:[100,0,0,0,0]}};
 const live=analyzeRace(entry,c,ix,'2025-12-09T18:00:00+09:00');assert.deepEqual(live.ranking,ix.evaluate(entry,c.ability,entry.off_at));
 // Original fixture differs in rank but matching data yields matching selected horse.
 const targetRace={...entry,status:'completed',payouts:races[0].payouts};const bt=backtest([targetRace],c,{evaluate:ix.evaluate});assert.equal(bt.excluded,live.candidate?0:1);if(live.candidate)assert.deepEqual(bt.rows[0].horses.map(h=>h.number),live.candidate.horses.map(h=>h.number));
});
test('実戦出走表は公開時刻で選ぶ。取消再計算・未公開／発走後拒否',async()=>{
 const calls=[];const run=createRunner(async url=>{const file=new URL(url).pathname.split('/lab/')[1];calls.push(file);return {ok:true,json:async()=>read(file)};},'https://example.test/lab/worker.js');
 await run({type:'init',manifest:read('data/manifest.json')});const a=await run({type:'analyze',raceId:'v2-upcoming-demo',config:cfg,asOf:'2026-10-03T18:00:00+09:00'});const b=await run({type:'analyze',raceId:'v2-upcoming-demo',config:cfg,asOf:'2026-10-04T10:00:00+09:00'});
 assert.equal(a.ranking.find(h=>h.number===2).reason,undefined);assert.equal(b.ranking.find(h=>h.number===2).reason,'出走取消・競走除外');assert.equal(calls.length,10);
 await assert.rejects(run({type:'analyze',raceId:'v2-upcoming-demo',config:cfg,asOf:'2026-10-02T18:00:00+09:00'}));await assert.rejects(run({type:'analyze',raceId:'v2-upcoming-demo',config:cfg,asOf:'2026-10-05T15:00:00+09:00'}));
});
test('Workerの能力履歴は検証開始年より前も使い、完了返答に詳細を載せずページだけ取得',async()=>{
 let calls=0;const run=createRunner(async url=>{calls++;const file=new URL(url).pathname.split('/lab/')[1];return {ok:true,json:async()=>read(file)};},'https://example.test/lab/worker.js');await run({type:'init',manifest:read('data/manifest.json')});
 const c={...cfg,startYear:2023};const out=await run({type:'backtest',config:c}),ix=createAbilityIndex(races),expected=backtest(races,c,{evaluate:(r,a,t)=>ix.evaluate(r,a,t,false)});
 assert.equal('rows' in out,false);assert.equal(out.payout,expected.payout);assert.equal(out.purchased,expected.purchased);assert.ok(out.purchased>0);
 const d=await run({type:'details',resultId:out.resultId,filter:'all',page:1});assert.equal(d.rows.length,15);assert.equal('horses' in d.rows[0].race,false);assert.equal('payouts' in d.rows[0].race,false);
 const r=await run({type:'assessment',resultId:out.resultId,raceId:d.rows.find(r=>r.ability).race.race_id});assert.equal(r.ranking.length,4);assert.ok(r.ranking[0].runs.length<=5);
 await run({type:'backtest',config:{...c,ticket:'place'}});assert.equal(calls,10);assert.ok(Buffer.byteLength(JSON.stringify({...out,chart:undefined}))<20000);
});
test('デフォルト値は戦略設定で上書きされない・不正な重みを拒否',()=>{
 const a=defaultAbility();a.components[0]=99;a.runs[0]=99;assert.deepEqual(DEFAULT_COMPONENTS,[30,20,30,20]);assert.deepEqual(DEFAULT_RUNS,[30,25,20,15,10]);assert.throws(()=>validateAbility(a));assert.throws(()=>validateAbility({components:[100,0,0,0],runs:[0,0,0,0,0]}));
});
test('別馬も手計算：G2=90×30%＋1着100×20%＋着差100×30%＋時計50×20%=87',()=>{
 const p=race('b-history','2020-01-02',[horse('b')],{grade:'G2'}),t=race('b-target','2020-02-01',[horse('b')]);assert.equal(createAbilityIndex([seed,p]).evaluate(t,cfg.ability)[0].score,87);
});
test('コンパクトな能力キャッシュと詳細評価が、重み変更と再変更でも完全一致',()=>{
 const ix=createAbilityIndex(races),t=upcoming[0],date='2026-10-03T18:00:00+09:00';
 for(const ability of [defaultAbility(),{components:[20,15,45,20],runs:[100,0,0,0,0]},defaultAbility()])for(let attempt=0;attempt<2;attempt++){
 const compact=ix.evaluate(t,ability,date,false),full=ix.evaluate(t,ability,date,true);assert.deepEqual(compact.map(h=>[h.number,h.score,h.rank,h.components,h.reason]),full.map(h=>[h.number,h.score,h.rank,h.components,h.reason]));assert.ok(compact.every(h=>!('runs' in h)));
 }
});
