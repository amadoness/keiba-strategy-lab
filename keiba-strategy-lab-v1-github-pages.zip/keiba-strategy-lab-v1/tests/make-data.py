import json,pathlib
root=pathlib.Path(__file__).resolve().parents[1]/'dist'/'data'
patterns=[[1,2,3,4],[2,3,1,4],[3,4,2,1],[4,2,3,1],[1,4,2,3],[2,1,4,3]]
place1=[120,180,None,None,140,130]
wide23=[360,420,510,620,None,None]
allr=[]
for i in range(18):
 year=2020+i//3;p=i%6;date=f'{year}-{(i%3)*3+3:02d}-15';order=patterns[p]
 horses=[dict(horse_id=f'fiction-{j}',name=['アオバスター','ルリノカゼ','コハクランナー','シロガネロード'][j-1],popularity=j,odds=[2.4,4.8,7.6,12.0][j-1],finish=order.index(j)+1,jockey=f'架空騎手{j}',gate=j,number=j,scratched=False) for j in range(1,5)]
 places=[dict(key=str(j),yen100=place1[p] if j==1 else 160+j*20) for j in order[:2]] # 4頭立ては複勝2着まで
 # patterns 1は1番人気3着なので非的中に変更し、手計算は9的中1170円
 wide=[dict(key='-'.join(map(str,sorted([a,b]))),yen100=wide23[p] if set([a,b])=={2,3} else 300+a*40+b*20) for a,b in [(order[0],order[1]),(order[0],order[2]),(order[1],order[2])]]
 r=dict(race_id=f'demo-{i+1:03}',date=date,track=['東京','中山','阪神'][i%3],race_number=11,name=f'架空・検証レース {i+1:02}',grade=['G1','G2','G3'][i%3],surface='芝' if i%2==0 else 'ダート',distance=[1600,1800,2000][i%3],going=['良','稍重','重','不良'][i%4],runners=4,status='completed',popularity_source='pre_off_snapshot',popularity_at=date+'T05:55:00Z',off_at=date+'T06:00:00Z',horses=horses,payouts={'win':{'complete':True,'winners':[{'key':str(order[0]),'yen100':240 if order[0]==1 else 480 if order[0]==2 else 760 if order[0]==3 else 1200}],'refunds':[]},'place':{'complete':True,'winners':places,'refunds':[]},'wide':{'complete':True,'winners':wide,'refunds':[]}})
 allr.append(r)
for y in range(2020,2026):(root/f'{y}.json').write_text(json.dumps([r for r in allr if r['date'].startswith(str(y))],ensure_ascii=False,indent=2))
(root/'manifest.json').write_text(json.dumps({'schemaVersion':1,'datasetId':'fiction-v1-18','label':'架空の検算データ','synthetic':True,'raceCount':18,'files':[{'year':y,'path':f'data/{y}.json'} for y in range(2020,2026)]},ensure_ascii=False,indent=2))
